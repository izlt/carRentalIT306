package Phase5;

public interface Cost {
	
}
