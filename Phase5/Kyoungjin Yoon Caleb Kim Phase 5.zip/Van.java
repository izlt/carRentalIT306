package Phase5;

public class Van extends Vehicle {

	@Override
	public int seatCapacity() {
		// TODO Auto-generated method stub
		return 8;
	}

	@Override
	public double rentalPrice() {
		// TODO Auto-generated method stub
		return 90.00;
	}

}
