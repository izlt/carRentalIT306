package Phase5;

public class Pickup extends Vehicle {

	@Override
	public int seatCapacity() {
		// TODO Auto-generated method stub
		return 5;
	}

	@Override
	public double rentalPrice() {
		// TODO Auto-generated method stub
		return 90.00;
	}

}
