package Phase5;

public class SUV extends Vehicle{

	@Override
	public int seatCapacity() {
		// TODO Auto-generated method stub
		return 5;
	}

	@Override
	public double rentalPrice() {
		// TODO Auto-generated method stub
		return 100.00;
	}

}
