package Phase5;

public class Luxury extends Vehicle {

	@Override
	public int seatCapacity() {
		// TODO Auto-generated method stub
		return 4;
	}

	@Override
	public double rentalPrice() {
		// TODO Auto-generated method stub
		return 100.00;
	}

}
