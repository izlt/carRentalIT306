package Phase5;

public class Sedan extends Vehicle {

	@Override
	public int seatCapacity() {
		// TODO Auto-generated method stub
		return 4;
	}

	@Override
	public double rentalPrice() {
		// TODO Auto-generated method stub
		return 80.00;
	}

}
